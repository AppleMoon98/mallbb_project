// import {Outlet} from "react-router-dom";
// import MainNav from "../../common/mainNav";

// export default function NoticeLayout() {
//   return (
//     <div>
//       <MainNav />
//       <Outlet />
//     </div>
//   );
// }
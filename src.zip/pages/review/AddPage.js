import AddComponent from "../../component/review/AddComponent";

const AddPage = () => {
    return (
        <div>
            <AddComponent/>
            글 등록
        </div>
    )
}

export default AddPage;
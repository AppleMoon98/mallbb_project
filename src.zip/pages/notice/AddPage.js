import Addcomponent from "../../component/notice/AddComponent"

const Addpage = () =>{
    return(
        <div>
            <Addcomponent/>
        </div>
    )
}

export default Addpage;
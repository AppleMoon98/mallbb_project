import ListComponent from "../../component/notice/ListComponent";
const ListPage = () =>{    
    return(
        <div>
            <ListComponent/>
        </div>
    )
}

export default ListPage;
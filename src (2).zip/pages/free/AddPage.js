import AddComponent from "../../component/free/AddComponent";
import MainNav from "../../common/MainNav";

const AddPage = () => {
    return (
        <div>
            <AddComponent/>
        </div>
    )
}

export default AddPage;
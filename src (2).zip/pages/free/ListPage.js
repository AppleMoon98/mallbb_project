import ListComponent from "../../component/free/ListComponent";
import Sidebar from "../../common/Sidebar";

const ListPage = () =>{    
    return(
        <div>
            <ListComponent/>
        </div>
    )
}

export default ListPage;
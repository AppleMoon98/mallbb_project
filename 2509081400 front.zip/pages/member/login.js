import LoginComponent from "../../component/member/LoginComponent";

const Login = () => {
  return (
    <div>
      <LoginComponent />
    </div>
  );
};

export default Login;




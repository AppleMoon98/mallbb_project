import MainNav from "../../common/mainNav";
import Addcomponent from "../../component/notice/AddComponent"

const Addpage = () =>{
    return(
        <div>
            <MainNav/>
            <Addcomponent/>
            글 등록
        </div>
    )
}

export default Addpage;